﻿namespace SoftJail.DataProcessor
{

    using Data;
    using Newtonsoft.Json;
    using SoftJail.Data.Models;
    using SoftJail.DataProcessor.ImportDto;
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.Text;

    public class Deserializer
    {
        private const string ErrorMessage = "Invalid Data";
        public static string ImportDepartmentsCells(SoftJailDbContext context, string jsonString)
        {
            StringBuilder sb = new StringBuilder();

            ImportDepartmentCellDTO[] departmentsDTO = JsonConvert.DeserializeObject<ImportDepartmentCellDTO[]>(jsonString);

            List<Department> validDepartments = new List<Department>();

            foreach (var departmentDTO in departmentsDTO)
            {
                if (!IsValid(departmentDTO))
                {
                    sb.AppendLine(ErrorMessage);
                    continue;
                }
                Department department = new Department
                {
                    Name = departmentDTO.Name
                };

                foreach (var cellDTO in departmentDTO.Cells)
                {
                    if (!IsValid(cellDTO))
                    {
                      //  sb.AppendLine(ErrorMessage);
                        continue;
                    }
                    department.Cells.Add(new Cell
                    {
                        CellNumber = cellDTO.CellNumber,
                        HasWindow = bool.Parse(cellDTO.HasWindow)
                    });
                }

                

                if(department.Cells.Count != departmentDTO.Cells.Count)
                {
                    sb.AppendLine(ErrorMessage);
                    continue;
                }

                validDepartments.Add(department);
                sb.AppendLine($"Imported {department.Name} with {department.Cells.Count} cells");
            }

            
            context.Departments.AddRange(validDepartments);
            context.SaveChanges();

            return sb.ToString().TrimEnd();
        }

        public static string ImportPrisonersMails(SoftJailDbContext context, string jsonString)
        {
            throw new NotImplementedException();
        }

        public static string ImportOfficersPrisoners(SoftJailDbContext context, string xmlString)
        {
            throw new NotImplementedException();
        }

        private static bool IsValid(object obj)
        {
            var validationContext = new System.ComponentModel.DataAnnotations.ValidationContext(obj);
            var validationResult = new List<ValidationResult>();

            bool isValid = Validator.TryValidateObject(obj, validationContext, validationResult, true);
            return isValid;
        }
    }
}