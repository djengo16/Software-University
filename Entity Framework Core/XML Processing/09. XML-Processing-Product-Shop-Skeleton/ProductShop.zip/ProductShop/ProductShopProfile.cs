﻿using AutoMapper;
using ProductShop.Dtos.Export;
using ProductShop.Dtos.Import;
using ProductShop.Models;

namespace ProductShop
{
    public class ProductShopProfile : Profile
    {
        public ProductShopProfile()
        {
            //users

            this.CreateMap<ImportUserDTO,User>();

            this.CreateMap<User, ExportSoldProductDTO>()
                .ForMember(u => u.SoldProducts, m => m.MapFrom(p => p.ProductsSold));

            //product

            this.CreateMap<ImportProductDTO, Product>();

            this.CreateMap<Product, ProductDTO>();

            
        }
    }
}
