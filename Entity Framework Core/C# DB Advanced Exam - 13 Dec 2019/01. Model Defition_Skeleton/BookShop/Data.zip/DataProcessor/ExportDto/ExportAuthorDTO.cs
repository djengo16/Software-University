﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BookShop.DataProcessor.ExportDto
{
    public class ExportAuthorDTO
    {

    }
  //  [
  //{
  //  "AuthorName": "Angelina Tallet",
  //  "Books": [
  //    {
  //      "BookName": "Allen Fissidens Moss",
  //      "BookPrice": "78.44"
  //    },
  //    {
  //      "BookName": "Earlyleaf Brome",
  //      "BookPrice": "63.66"
  //    },

}
