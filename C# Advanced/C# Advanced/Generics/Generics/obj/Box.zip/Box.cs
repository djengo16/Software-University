﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Generics
{
    public class Box<T>
    {
       

        public Box()
        {
            this.Values = new List<T>();
        }

        public List<T> Values { get; set; }



        public void Swap(int index1,int index2)
        {
            T tempValue = this.Values[index1];
            this.Values[index1] = this.Values[index2];
            this.Values[index2] = tempValue;
        }


        public override string ToString()
        {
            StringBuilder sb = new StringBuilder();

            foreach (var item in this.Values)
            {
                sb.AppendLine(($"{item.GetType()}: {item}"));
            }

            string result = sb.ToString().TrimEnd();
            return result;
        }

    }
}
