﻿namespace Generics
{
    using System;
    using System.Collections.Generic;
    using System.Linq;

    class Program
    {
        static void Main(string[] args)
        {

            int counter = int.Parse(Console.ReadLine());

            Box<string> box = new Box<string>();

            for (int i = 0; i < counter; i++)
            {
                var input = Console.ReadLine();

                box.Values.Add(input);
            }

            var indexes = Console.ReadLine()
                .Split()
                .Select(int.Parse)
                .ToArray();

            box.Swap(indexes[0], indexes[1]);

            Console.WriteLine(box);

            //int counter = int.Parse(Console.ReadLine());

            //for (int i = 0; i < counter; i++)
            //{
            //    int value = int.Parse(Console.ReadLine());
            //    Box<int> box = new Box<int>(value);
            //    Console.WriteLine(box.ToString());
            //}
        }
    }
}
