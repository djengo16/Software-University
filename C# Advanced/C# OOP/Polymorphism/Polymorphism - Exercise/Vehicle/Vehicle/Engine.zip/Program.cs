﻿using System;

namespace Vehicle
{
    class Program
    {
        static void Main(string[] args)
        {
            Engine engine = new Engine();
            engine.StartProgram();
        }
    }
}
